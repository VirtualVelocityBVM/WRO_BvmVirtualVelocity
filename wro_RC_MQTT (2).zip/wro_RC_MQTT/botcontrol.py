# Import the pygame module

import pygame

from paho.mqtt import client as mqtt_client
import argparse
import random
from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_ESCAPE,
    KEYDOWN,
    KEYUP,
    QUIT,
    K_w,
    K_a,
    K_s,
    K_d,
    K_l,
    K_p,
    K_q,
    K_e
)


broker = "192.168.4.2"  # "broker.emqx.io"  # "192.168.168.94"  # "broker.emqx.io"
port = 1883
topic = "cvpro"
# generate client ID with pub prefix randomly
client_id = f"python-mqtt"
username = "cvpro"
password = "cvpro"


parser = argparse.ArgumentParser(description="Control the Bot.")

parser.add_argument(
    "--control", type=int, default=255, help="integer values to send to bot"
)

args = parser.parse_args()
print(args.control)

x = args.control


# Initialize pygame
def init():
    pygame.init()
    display_surface = pygame.display.set_mode((300, 300))


def connect_mqtt():
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def publish(client):
    running = True
    released_keys = set()  # Store the released keys
    while running:
        msg = ""  # Initialize the message as empty
        for event in pygame.event.get():
            # if event.type == KEYDOWN:
            #     # Handle keydown events

            #     if event.key == K_w:
            #         if pygame.key.get_pressed()[K_a]:
            #             msg = "a"
            #         elif pygame.key.get_pressed()[K_d]:
            #             msg = "d"
            #         else:
            #             msg = "w"

            if event.type == KEYDOWN:
                keys = pygame.key.get_pressed()


                if keys[K_w]:
                    msg = "3800,230"

                elif keys[K_a]:
                    msg = "2500,220"

                elif keys[K_d]:
                    msg = "4500,220"

                elif keys[K_q]:
                    msg = "2000,255"

                elif keys[K_e]:
                    msg = "4400,255"

                # if keys[K_w] and keys[K_a]:
                #     msg = "a"
                # elif keys[K_w] and keys[K_d]:
                #     msg = "d"


                # elif event.key == K_a:
                #     if pygame.key.get_pressed()[K_w]:
                #         msg = "a"
                #     else:
                #         msg = "q"

                # elif event.key == K_d:
                #     if pygame.key.get_pressed()[K_w]:
                #         msg = "d"
                #     else:
                #         msg = "e"

                elif event.key == K_s:
                    msg = "3800,-220"
                
                elif event.key == K_l:
                    msg = "l"
                    print("login start")
                elif event.key == K_p:
                    msg = "p"
                    print("login stop")
                elif event.key == K_ESCAPE:
                    running = False
                
                if msg:
                    result = client.publish(topic, msg)
                    print(msg)

            elif event.type == KEYUP:
                # Handle keyup events
                if event.key == K_w:
                    released_keys.add(K_w)
                elif event.key == K_a:
                    released_keys.add(K_a)
                elif event.key == K_d:
                    released_keys.add(K_d)
                elif event.key == K_s:
                    released_keys.add(K_s)
                elif event.key == K_q:
                    released_keys.add(K_q)
                elif event.key == K_e:
                    released_keys.add(K_e)


        # 207 to 225 added only because to stop the bot of o,o values that y added for servo not
         # need for cvpro classic
        if K_w in released_keys:
            msg = "0,0"
            result = client.publish(topic, msg)
            print(msg)

        if K_s in released_keys:
            msg = "0,0"
            result = client.publish(topic, msg)
            print(msg)

        if K_a in released_keys:
            msg = "0,0"
            result = client.publish(topic, msg)
            print(msg)

        # if K_d in released_keys:
        #     msg = "o"
        #     result = client.publish(topic, msg)
        #     print(msg)

        # if K_e in released_keys:
        #     msg = "o"
        #     result = client.publish(topic, msg)
        #     print(msg)




        # Check released keys and publish messages
        if K_w in released_keys:
            if K_a in released_keys or K_d in released_keys:
                msg = "0,0"       
            else:
                msg = "0,0"
            
            if msg:
                result = client.publish(topic, msg)
                print(msg)
            released_keys.remove(K_w)

        # Check released keys and publish messages
        if K_s in released_keys:
            msg = "0,0"
            result = client.publish(topic, msg)
            print(msg)
            released_keys.remove(K_s)


        if K_a in released_keys:
            if K_w in released_keys:
                msg = "0,0"
            else:
                msg = "0,0"
            if msg:
                result = client.publish(topic, msg)
                print(msg)
            released_keys.remove(K_a)

        if K_d in released_keys:
            if K_w in released_keys:
                msg = "0,0"
            else:
                msg = "0,0"
            if msg:
                result = client.publish(topic, msg)
                print(msg)
            released_keys.remove(K_d)

         # Check released keys and publish messages for Q and E keys
        if K_q in released_keys or K_e in released_keys:
            msg = "0,0"
            if msg:
                result = client.publish(topic, msg)
                print(msg)
            # Remove both Q and E keys from released_keys
            if K_q in released_keys:
                released_keys.remove(K_q)
            if K_e in released_keys:
                released_keys.remove(K_e)



        if event.type == QUIT:
            running = False





def run():
    client = connect_mqtt()
    client.loop_start()
    publish(client)


if __name__ == "__main__":
    init()
    run()

# # Import the pygame module

# import pygame

# from paho.mqtt import client as mqtt_client
# import argparse
# import random
# from pygame.locals import (
#     K_UP,
#     K_DOWN,
#     K_LEFT,
#     K_RIGHT,
#     K_ESCAPE,
#     KEYDOWN,
#     KEYUP,
#     QUIT,
#     K_w,
#     K_a,
#     K_s,
#     K_d,
#     K_l,
#     K_p,
# )


# broker = "10.0.0.2"  # "broker.emqx.io"  # "192.168.168.94"  # "broker.emqx.io"
# port = 1883
# topic = "bot"
# # generate client ID with pub prefix randomly
# client_id = f"python-mqtt"
# username = "cvpro"
# password = "cvpro"


# parser = argparse.ArgumentParser(description="Control the Bot.")

# parser.add_argument(
#     "--control", type=int, default=255, help="integer values to send to bot"
# )

# args = parser.parse_args()
# print(args.control)

# x = args.control


# # Initialize pygame
# def init():
#     pygame.init()
#     display_surface = pygame.display.set_mode((500, 500))


# def connect_mqtt():
#     def on_connect(client, userdata, flags, rc):
#         if rc == 0:
#             print("Connected to MQTT Broker!")
#         else:
#             print("Failed to connect, return code %d\n", rc)

#     client = mqtt_client.Client(client_id)
#     client.username_pw_set(username, password)
#     client.on_connect = on_connect
#     client.connect(broker, port)
#     return client


# def publish(client):
#     angle = 3200
#     speed = 200
#     msg = ""
#     running = True
#     while running:
#         for event in pygame.event.get():
#             if event.type == KEYDOWN:
#                 if event.key == K_w:
#                     # if pygame.key.get_pressed()[K_a]:
#                     #     msg = f"{-int(x * 0.5)}, {x}"
#                     # elif pygame.key.get_pressed()[K_d]:
#                     #     msg = f"{x}, {-int(x * 0.5)}"
#                     # else:
#                     msg = f"{angle,speed}"

#                 elif event.key == K_s:
#                     msg = f"{angle,-speed}"


#                 elif event.key == K_a:
#                     if pygame.key.get_pressed()[K_w]:
#                         msg = f"{2500,speed}"
#                     else:
#                         msg = f"{2200,speed}"

#                 elif event.key == K_d:
#                     if pygame.key.get_pressed()[K_w]:
#                         msg = f"{4500,speed}"
#                     else:
#                         msg = f"{4800,speed}"
                        
#                 elif event.key == K_l:
#                     msg = "l"
#                     print("login start")


#                 elif event.key == K_p:
#                     msg = "p"
#                     print("login stop")

#                 elif event.key == K_ESCAPE:
#                     running = False
#                 print(msg)
#                 result = client.publish(topic, msg)

#             if event.type == KEYUP:
#                 if event.key == K_w:
#                     msg = f"{0}, {0}"
#                 elif event.key in [K_a, K_d]:
#                     if pygame.key.get_pressed()[K_w]:
#                         msg = f"{3200}, {speed}"
#                     elif pygame.key.get_pressed()[K_s]:
#                         msg = f"{3200}, {speed}"
#                     else:
#                         msg = f"{0}, {0}"
#                 elif event.key == K_s:
#                     msg = f"{0}, {0}"

#                 print(msg)
#                 result = client.publish(topic, msg)

#             if event.type == QUIT:
#                 running = False

#             # status = result[0]
#             # if status == 0:
#             #     print(f"Send {msg} to topic {topic}")
#             # else:
#             #     print(f"Failed to send message to topic {topic}")


# def run():
#     client = connect_mqtt()
#     client.loop_start()
#     publish(client)


# if __name__ == "__main__":
#     init()
#     run()

